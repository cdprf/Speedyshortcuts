import{Fr as e,Kr as t,Lr as n,Mr as r,Pr as i,Ur as a,Zr as o,kr as s,n as c,t as l,zr as u}from"./useAppTheme-RU8yYYHr.js";var d=`# Changelog

See what is new and improved in each release of Nice Speed Dials.

## v6 — Carbon (2026-08-31)

### What's new

- Create folders and organize your speed dials in nested folder hierarchies.
- Navigate between folders using a clickable breadcrumb path.
- Choose a custom folder icon from a searchable icon library.
- Choose a destination folder when creating or editing a speed dial.
- Edit, duplicate, and delete folders. Duplicating a folder also copies
  everything inside it.
- Open every speed dial inside a folder and its subfolders in new tabs.
- Right-click any webpage and select **Add to Speed Dials** to save it quickly.
- Use Nice Speed Dials on Chrome, Firefox, and Edge.
- Choose whether speed dial titles are displayed below their icons.
- Empty folders now include a helpful shortcut for adding the first item.
- View a dedicated update page after an extension update, with release notes,
  review, and support options.
- Leave a review or support ongoing development from Settings or the update
  page.
- Share feedback through a short survey when uninstalling the extension.

### Improvements

- Improved the create and edit window for working with both speed dials and
  folders.
- Forms can now be submitted with Enter and include clearer labels and controls
  for keyboard and assistive-technology users.
- Invalid names and website addresses now show clearer inline error messages.
- Refreshed the new tab page, themes, animations, and component styling for a
  more consistent interface.
- Improved the layout and responsiveness of the grid, folder navigation, and
  settings interface.

### Fixes

- Fixed browser context-menu errors and duplicate menu entries.
- Prevented the browser's native link dragging from interfering when speed dials
  are rearranged.
- Fixed tooltips occasionally closing or becoming stuck unexpectedly.
- Improved recovery when the Nice Speed Dials bookmark folder is moved, deleted,
  or changed outside the extension.

## v5 — Boron (2025-11-03)

### What's new

- Added a settings drawer with persistent customization options.
- Choose a custom background color or upload a background image.
- Turn dark mode on or off.
- Customize the number of grid columns, dial size, and dial corner radius.
- Show or hide the **Add New** and **Settings** buttons.
- Choose whether links open in the current tab or a new tab by default.
- Disable drag and drop when you do not want dials to be moved accidentally.
- Reset individual options or restore every setting to its default value.
- Open Settings from the right-click menu, even when the Settings button is
  hidden.
- Added smooth animations while rearranging speed dials.

### Improvements

- Redesigned the interface with clearer controls, menus, dialogs, and tooltips.
- Moved the Add New and Settings controls into a dedicated toolbar so they are
  not mixed with draggable speed dials.
- Made the extension more reliable when its bookmark folder is missing or has
  been deleted.

### Fixes

- Fixed tooltip behavior and several issues affecting the grid, dialogs, context
  menus, and settings.

## v4 — Beryllium (2023-07-22)

### Fixes

- Fixed speed dials not updating after bookmarks were created, edited, moved, or
  removed.
- Fixed reordered speed dials sometimes displaying or saving in the wrong order.

## v3 — Lithium (2023-07-21)

### What's new

- Reorder speed dials with drag and drop. The new order is saved directly to
  your browser bookmarks.
- Added animated feedback while rearranging the grid.

### Improvements

- Refreshed the icons used throughout the extension.

## v2 — Helium (2023-01-11)

### What's new

- Duplicate an existing speed dial from its context menu.
- See a speed dial's full destination URL when hovering over it.

### Improvements

- Improved grid performance.

### Fixes

- Fixed multiple copies of the Nice Speed Dials bookmark folder being created
  during startup.

## v1 — Hydrogen (2023-01-08)

### What's new

- Create, edit, and delete speed dials using simple dialogs and context menus.
- Store speed dials as browser bookmarks so they can follow browser bookmark
  sync across devices.
- Automatically create and manage the dedicated Nice Speed Dials bookmark
  folder.
- Display website favicons for quick visual recognition.
- Validate website addresses before saving a speed dial.
- Show helpful confirmation messages and notifications after actions.
- Display speed dial details when hovering over a dial.
`,f=n(`<strong>`),p=n(`<div class="min-h-screen w-full bg-(--app-background-color,#2c2124) bg-no-repeat p-4 text-foreground [background-image:var(--app-background-image,none)] bg-position-(--app-background-position,auto) bg-size-(--app-background-size,auto) sm:p-8"><main class="mx-auto w-full max-w-3xl"><header class="border-b border-border pb-8 sm:pb-10"><p class="mb-3 font-medium text-primary text-sm">NICE SPEED DIALS</p><h1 class="max-w-xl font-heading font-semibold text-3xl tracking-tight sm:text-4xl"></h1><p class="mt-3 max-w-2xl text-base text-muted-foreground leading-6">A fresh round of improvements for the new tab you use every day.</p><div class=mt-6></div></header><section id=release-notes class="py-8 sm:py-10"aria-labelledby=release-notes-title><div class=mb-7><h2 id=release-notes-title class="font-heading font-semibold text-xl">Release notes</h2></div><div class="overflow-hidden rounded-2xl border border-border bg-background/88 shadow-sm/5">`),m=n(`<article class="p-5 sm:p-7"><header class="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1"><h3 class="font-heading font-semibold text-xl tracking-tight text-primary"></h3><time class="text-muted-foreground text-sm"></time></header><div class="mt-6 space-y-6">`),h=n(`<section><h4 class="font-medium text-foreground text-sm"></h4><ul class="mt-3 space-y-2 text-muted-foreground text-sm leading-6">`),g=n(`<li class="relative ps-4 before:absolute before:inset-s-0 before:top-2.5 before:size-1 before:rounded-full before:bg-primary/72">`),_=e=>e.split(/^## /m).slice(1).map(e=>{let[t=``,...n]=e.trim().split(`
`),r=t.match(/^(.*?)\s+\(([^)]+)\)$/);return{version:r?.[1]??t,date:r?.[2],sections:n.join(`
`).split(/^### /m).slice(1).map(e=>{let[t=``,...n]=e.trim().split(`
`);return{title:t,entries:n.join(`
`).trim().split(/\n(?=- )/).map(e=>e.replace(/^- /,``).replace(/\n\s*/g,` `).trim()).filter(Boolean)}})}}),v=e=>e.split(/(\*\*[^*]+\*\*)/).map(e=>e.startsWith(`**`)&&e.endsWith(`**`)?(()=>{var t=f();return r(t,()=>e.slice(2,-2)),t})():e),y=_(d),b=()=>{let n=y[0];return o(()=>{document.title=`Release notes | Nice Speed Dials`}),(()=>{var i=p(),o=i.firstChild.firstChild,l=o.firstChild.nextSibling,d=l.nextSibling.nextSibling,f=o.nextSibling.firstChild.nextSibling;return r(l,()=>n?`${n.version} is here`:`Release notes`),r(d,a(c,{isUpdatePage:!0})),r(f,a(u,{each:y,children:(n,i)=>(()=>{var o=m(),c=o.firstChild,l=c.firstChild,d=l.nextSibling,f=c.nextSibling;return r(l,()=>n.version),r(d,()=>n.date),r(f,a(u,{get each(){return n.sections},children:i=>(()=>{var o=h(),s=o.firstChild,c=s.nextSibling;return r(s,()=>i.title),r(c,a(u,{get each(){return i.entries},children:e=>(()=>{var t=g();return r(t,()=>v(e)),t})()})),t(t=>{var r=`${n.version}-${i.title}`,a=`${n.version}-${i.title}`;return r!==t.e&&e(o,`aria-labelledby`,t.e=r),a!==t.t&&e(s,`id`,t.t=a),t},{e:void 0,t:void 0}),o})()})),t(e=>s(o,{"border-t border-border":i()>0},e)),o})()})),i})()},x=()=>(l({useCustomBackground:!1}),a(b,{}));i(()=>a(x,{}),document.getElementById(`root`));